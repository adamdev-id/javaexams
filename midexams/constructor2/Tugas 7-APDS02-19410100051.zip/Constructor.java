package tugasFirdaus;

public class Constructor
{
	private String productName;
	private int Amount;
	private int Price;
	
	public Constructor(String productName, int Amount, int Price)
	{
		this.productName = productName;
		this.Amount = Amount;
		this.Price = Price;
	}
	
	public Constructor(String productName)
	{
		this.productName = productName;
	}
	
	public Constructor(int Amount)
	{
		this.Amount = Amount;
	}
	
	public String getProductName()
	{
		return this.productName;
	}
	
	public int getAmount()
	{
		return this.Amount;
	}
	
	public int getPrice()
	{
		return this.Price;
	}
	
	public int getTotal()
	{
		return getAmount() * getPrice();
	}
	
	public void showMenu_Print()
	{
		System.out.println("= - Result - =");
		System.out.println("Product Name : " + getProductName());
		System.out.println("Buy Amount   : " + getAmount());
		System.out.println("Server Price : " + getPrice());
		System.out.println("Total        : " + getTotal());
	}
}
