package tugasFirdaus;


import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;


public class Main
{
	
	public static void main(String[] args) throws IOException
	{
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		Constructor Menu = new Constructor("", 0, 0);
		String space = " ";
		String Name = "";
		String oldName = "";
		String newName = "";
		String idSearch = "";
		String nameSearch = "";
		int Pilihan;
		int Pilihan2;
		int found = 0;
		int Amount = 0;
		int Price = 0;
		int oldAmount = 0;
		int newAmount = 0;
		String showMenu_Main = ""
			+ "- = Adam's Host = -     \n"
			+ " [1] Input menu         \n"
			+ " [2] Cetak menu         \n"
			+ " [3] Ubah menu          \n"
			+ " \t 1. Ubah Nama Produk \n"
			+ " \t 2. Ubah Jumlah Beli \n"
			+ " \t 3. Keluar           \n"
			+ " [4] Keluar             \n"
			+ "Masukkan Pilihan :      \n";
		
		String showMenu_Panel = ""
			+ "= - Adam's Host - =   \n"
			+ "[1] Ubah Nama Produk \n"
			+ "[2] Ubah Jumlah Beli \n"
			+ "[3] Keluar           \n"
			+ "Masukkan Pilihan :    \n";
		
		String[][] showMenu_DaftarProduk = {
			{ " [1]", "Server Reguler     " },
			{ " [2]", "Server Bisnis      " },
			{ " [3]", "Server Eksekutif   " }
		};
		
		while (true)
		{
			
			System.out.print(showMenu_Main);
			System.out.print("> ");
			Pilihan = Integer.parseInt(br.readLine());
			System.out.println(" \n");
			switch (Pilihan)
			{
			case 1:
				System.out.println("= - Adam's Product - =");
				for (int i = 0; i < showMenu_DaftarProduk.length; i++) //cetak baris
					for (int j = 0; j < 1; j++) //cetak kolom
					{
						{
							System.out.print(showMenu_DaftarProduk[i][0] + " " + showMenu_DaftarProduk[i][1]); //Print Daftar Server
							
						}
						System.out.println(""); //enter baris
					}
				System.out.println("= - User Input - =");
				System.out.println("Ketik Nama Produk : ");
				System.out.print("> ");
				Name = br.readLine();
				System.out.println("Ketik Jumlah yang akan Dibeli : ");
				System.out.print("> ");
				Amount = Integer.parseInt(br.readLine());
				System.out.println("Ketik Harga Produk ( Satuan ) : ");
				System.out.print("> ");
				Price = Integer.parseInt(br.readLine());
				Menu = new Constructor(Name, Amount, Price);
				System.out.println("");
				continue;
			case 2:
				Menu.showMenu_Print();
				System.out.println(space);
				continue;
			case 3:
				System.out.print(showMenu_Panel);
				System.out.print("> ");
				Pilihan2 = Integer.parseInt(br.readLine());
				System.out.println(space);
				switch (Pilihan2)
				{
				case 1:
					System.out.println("= - Ubah Nama - =");
					System.out.print("Masukkan Nama Lama : ");
					oldName = br.readLine();
					System.out.print("Masukkan Nama Baru : ");
					newName = br.readLine();
					if (oldName.toLowerCase().contains(Menu.getProductName().toLowerCase()))
					{
						Menu = new Constructor(newName, Amount, Price);
						System.out.println("Nama Berhasil Dirubah.");
						System.out.println("Dari : [" + oldName + "] menjadi [" + newName + "] ");
					}
					else
					{
						System.out.println("Nama Lama : [" + oldName + "] Tidak ditemukan.");
					}
					System.out.println(space);
					continue;
				case 2:
					System.out.println("= - Ubah Jumlah - =");
					System.out.print("Masukkan Jumlah Lama : ");
					oldAmount = Integer.parseInt(br.readLine());
					System.out.print("Masukkan Jumlah Baru : ");
					newAmount = Integer.parseInt(br.readLine());
					if (oldAmount == Menu.getAmount())
					{
						Menu = new Constructor(Name, newAmount, Price);
						System.out.println("Jumlah Berhasil Dirubah.");
						System.out.println("Dari : [" + oldAmount + "] menjadi [" + newAmount + "] ");
					}
					else
					{
						System.out.println("Jumlah Lama : [" + oldAmount + "] Tidak ditemukan.");
					}
					System.out.println(space);
					continue;
				
				default:
					System.exit(0);
					continue;
				}
			}
			System.exit(0);
			break;
		}
	}
}
